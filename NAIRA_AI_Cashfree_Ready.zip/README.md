# Naira AI Cashfree Starter

Upload these files to GitHub, then deploy as a Render Web Service. Keep secrets in Render Environment Variables, never in GitHub.
