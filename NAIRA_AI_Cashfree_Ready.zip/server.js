require('dotenv').config();
const express=require('express'); const path=require('path');
const app=express(); app.use(express.json()); app.use(express.static(path.join(__dirname,'public')));
app.get('/health',(req,res)=>res.json({ok:true}));
app.listen(process.env.PORT||3000,()=>console.log('Naira AI server running'));
